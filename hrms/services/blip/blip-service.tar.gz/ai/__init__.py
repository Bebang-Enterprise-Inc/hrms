"""Blip AI components powered by Claude."""
