"""
Multi-Model AI Intent Parser

Uses Claude Haiku 4.5 for intent parsing (fast, accurate)
Uses Gemini 3 Flash for response formatting (fast, cheap)
"""

import json
import logging
from datetime import datetime, timedelta
from typing import Any

import anthropic
from google import genai

from .prompts import INTENT_PARSER_SYSTEM, RESPONSE_FORMATTER_SYSTEM

logger = logging.getLogger(__name__)


class IntentParser:
    """
    Multi-model AI parser for Blip.

    - Claude Haiku 4.5: Intent parsing (fast, accurate extraction)
    - Gemini 3 Flash: Response formatting (fast, cheap generation)
    """

    def __init__(
        self,
        api_key: str,
        gemini_api_key: str,
        model: str = "claude-haiku-4-5-20251101",
        gemini_model: str = "gemini-3-flash"
    ):
        """
        Initialize the multi-model parser.

        Args:
            api_key: Anthropic API key
            gemini_api_key: Google Gemini API key
            model: Claude model for intent parsing
            gemini_model: Gemini model for response formatting
        """
        # Claude for intent parsing
        self.claude = anthropic.Anthropic(api_key=api_key)
        self.claude_model = model

        # Gemini for response formatting
        self.gemini = genai.Client(api_key=gemini_api_key)
        self.gemini_model = gemini_model

    async def parse(self, message: str, user_context: dict) -> dict:
        """
        Parse a user message into a structured intent using Claude.

        Args:
            message: The user's question
            user_context: Context about the user (permissions, store, etc.)

        Returns:
            Parsed intent with entities
        """
        try:
            # Add context about the user to help with parsing
            context_info = self._build_context_string(user_context)

            # Use Claude for intent parsing (fast, accurate extraction)
            response = self.claude.messages.create(
                model=self.claude_model,
                max_tokens=500,
                system=INTENT_PARSER_SYSTEM,
                messages=[
                    {
                        "role": "user",
                        "content": f"{context_info}\n\nUser message: {message}"
                    }
                ]
            )

            # Extract JSON from response
            response_text = response.content[0].text.strip()

            # Handle markdown code blocks
            if response_text.startswith("```"):
                response_text = response_text.split("```")[1]
                if response_text.startswith("json"):
                    response_text = response_text[4:]

            parsed = json.loads(response_text)
            parsed["original_message"] = message

            # Resolve relative dates
            parsed["entities"] = self._resolve_dates(parsed.get("entities", {}))

            return parsed

        except json.JSONDecodeError as e:
            logger.error(f"Failed to parse Claude response as JSON: {e}")
            return {
                "intent": "unknown",
                "entities": {},
                "confidence": 0.0,
                "original_message": message
            }
        except Exception as e:
            logger.exception(f"Error parsing intent: {e}")
            return {
                "intent": "unknown",
                "entities": {},
                "confidence": 0.0,
                "original_message": message,
                "error": str(e)
            }

    async def format_response(
        self,
        intent: str,
        data: dict,
        user_context: dict
    ) -> str:
        """
        Format query results into a human-readable response.

        Args:
            intent: The intent type
            data: Query result data
            user_context: User context

        Returns:
            Formatted response string
        """
        # Handle special response types
        if data.get("type") == "help":
            return self._get_help_response()

        if data.get("type") == "greeting":
            name = data.get("user_name", "").split()[0] if data.get("user_name") else ""
            greeting = f"Hi{' ' + name if name else ''}!"
            return f"{greeting} I'm Blip, BEI's AI assistant. How can I help you today?"

        if data.get("type") == "unknown":
            return (
                "I'm not sure I understood that question. "
                "Could you please rephrase it?\n\n"
                "I can help with: sales, food cost, inventory, "
                "commissary production, leave, attendance, and weather."
            )

        if data.get("error"):
            return f"Sorry, I couldn't retrieve that information: {data['error']}"

        if not data or data.get("empty"):
            return "No data found for your query."

        try:
            # Use Gemini 3 Flash for response formatting (fast, cheap)
            prompt = (
                f"{RESPONSE_FORMATTER_SYSTEM}\n\n"
                f"Format this {intent} data into a helpful response:\n\n"
                f"{json.dumps(data, indent=2, default=str)}"
            )

            response = self.gemini.models.generate_content(
                model=self.gemini_model,
                contents=prompt
            )

            return response.text.strip()

        except Exception as e:
            logger.exception(f"Error formatting response: {e}")
            # Fallback to simple formatting
            return self._simple_format(intent, data)

    def _build_context_string(self, user_context: dict) -> str:
        """Build context string for intent parsing."""
        parts = []

        if user_context.get("is_admin"):
            parts.append("User is an admin with full access to all data.")
        else:
            if user_context.get("store"):
                parts.append(f"User's store: {user_context['store']}")
            if user_context.get("area"):
                parts.append(f"User's area: {user_context['area']}")
            if user_context.get("employee"):
                parts.append(f"User's employee ID: {user_context['employee']}")

        parts.append(f"Current date: {datetime.now().strftime('%Y-%m-%d')}")
        parts.append(f"Current day: {datetime.now().strftime('%A')}")

        return "\n".join(parts) if parts else "No additional context."

    def _resolve_dates(self, entities: dict) -> dict:
        """Resolve relative date references to actual dates."""
        period = entities.get("period")
        today = datetime.now().date()

        if period == "today":
            entities["date"] = today.isoformat()
        elif period == "yesterday":
            entities["date"] = (today - timedelta(days=1)).isoformat()
        elif period == "tomorrow":
            entities["date"] = (today + timedelta(days=1)).isoformat()

        return entities

    def _get_help_response(self) -> str:
        """Return help text."""
        return """I'm Blip, BEI's AI assistant. Here's what I can help you with:

**Sales Data**
- "What are sales at Market Market today?"
- "Compare Megamall vs Trinoma this week"
- "Top performing stores yesterday"

**Food Cost**
- "What's the food cost at BGC stores?"
- "Which stores have food cost above 35%?"

**Commissary**
- "How much FM was produced today?"
- "Leche Flan production this week"

**Inventory**
- "Stock levels at Uptown Mall"
- "Which stores are low on cups?"

**HR & Attendance**
- "Who's on leave tomorrow?"
- "My leave balance"
- "Team attendance today"

**Weather**
- "What's the weather forecast?"
- "Will it rain tomorrow?"

Just ask naturally - I'll understand!"""

    def _simple_format(self, intent: str, data: dict) -> str:
        """Simple fallback formatting."""
        if isinstance(data, dict):
            lines = []
            for key, value in data.items():
                if key not in ["type", "empty", "error"]:
                    lines.append(f"- {key}: {value}")
            return "\n".join(lines) if lines else "Data retrieved successfully."
        return str(data)
