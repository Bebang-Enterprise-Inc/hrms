"""
Blip Configuration

Environment variables loaded from .env or system environment.
"""

from pydantic_settings import BaseSettings
from typing import Optional


class Settings(BaseSettings):
    """Blip service configuration."""

    # Service
    SERVICE_NAME: str = "blip"
    SERVICE_PORT: int = 8766
    LOG_LEVEL: str = "INFO"

    # Frappe API
    FRAPPE_URL: str = "https://hq.bebang.ph"
    FRAPPE_API_KEY: str = ""
    FRAPPE_API_SECRET: str = ""

    # Claude AI - for intent parsing
    ANTHROPIC_API_KEY: str = ""
    CLAUDE_MODEL: str = "claude-haiku-4-5-20251101"  # Haiku 4.5 - fast intent detection

    # Gemini AI - for response formatting
    GEMINI_API_KEY: str = ""  # Gemini API key (maps to GOOGLE_API_KEY internally)
    GEMINI_MODEL: str = "gemini-3-flash"  # Fast response formatting

    # Google Service Account (for sending proactive messages to Chat)
    GOOGLE_SERVICE_ACCOUNT_FILE: Optional[str] = None

    # Admin users (full access)
    ADMIN_EMAILS: list[str] = ["sam@bebang.ph"]

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"


settings = Settings()
