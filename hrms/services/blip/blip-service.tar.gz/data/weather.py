"""
Weather Data Module

Fetches weather data from Open-Meteo API (free, no API key required).
"""

import logging
from datetime import datetime, timedelta
from typing import Optional

import httpx

logger = logging.getLogger(__name__)

# Metro Manila coordinates
METRO_MANILA_LAT = 14.5995
METRO_MANILA_LON = 120.9842

# Weather code descriptions
WEATHER_DESCRIPTIONS = {
    0: "Clear sky",
    1: "Mainly clear",
    2: "Partly cloudy",
    3: "Overcast",
    45: "Foggy",
    48: "Depositing rime fog",
    51: "Light drizzle",
    53: "Moderate drizzle",
    55: "Dense drizzle",
    61: "Slight rain",
    63: "Moderate rain",
    65: "Heavy rain",
    66: "Light freezing rain",
    67: "Heavy freezing rain",
    71: "Slight snow",
    73: "Moderate snow",
    75: "Heavy snow",
    80: "Slight rain showers",
    81: "Moderate rain showers",
    82: "Violent rain showers",
    95: "Thunderstorm",
    96: "Thunderstorm with slight hail",
    99: "Thunderstorm with heavy hail"
}

# Business impact based on weather
WEATHER_IMPACT = {
    0: "Peak sales expected - high foot traffic",
    1: "Good sales conditions",
    2: "Normal traffic expected",
    3: "Steady traffic, consider warm drink promotions",
    45: "Slower morning, picks up by lunch",
    51: "Slight dip in walk-ins, push delivery",
    53: "Moderate impact, focus on delivery",
    55: "Lower foot traffic, delivery focus",
    61: "Walk-in traffic down, push delivery channels",
    63: "Significant impact on walk-ins",
    65: "Expect slow day, prioritize staff safety",
    80: "Unpredictable traffic, be ready for rushes",
    81: "Delivery focus day",
    82: "Low walk-in traffic",
    95: "Storm warning - check store protocols"
}


async def get_weather_forecast(entities: dict) -> dict:
    """
    Get weather forecast for Metro Manila.

    Args:
        entities: Parsed entities (may include date)

    Returns:
        Weather data dict
    """
    try:
        async with httpx.AsyncClient() as client:
            response = await client.get(
                "https://api.open-meteo.com/v1/forecast",
                params={
                    "latitude": METRO_MANILA_LAT,
                    "longitude": METRO_MANILA_LON,
                    "current": "temperature_2m,apparent_temperature,relative_humidity_2m,weather_code,wind_speed_10m",
                    "daily": "weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max,precipitation_sum,sunrise,sunset",
                    "timezone": "Asia/Manila",
                    "forecast_days": 3
                },
                timeout=10
            )
            response.raise_for_status()
            data = response.json()

        # Parse current weather
        current = data.get("current", {})
        current_code = current.get("weather_code", 0)

        # Parse daily forecast
        daily = data.get("daily", {})
        forecast_days = []

        today = datetime.now().date()
        for i, date_str in enumerate(daily.get("time", [])[:3]):
            date = datetime.strptime(date_str, "%Y-%m-%d").date()
            code = daily["weather_code"][i]

            day_label = "Today" if date == today else (
                "Tomorrow" if date == today + timedelta(days=1) else
                date.strftime("%A")
            )

            forecast_days.append({
                "date": date_str,
                "day": day_label,
                "condition": WEATHER_DESCRIPTIONS.get(code, f"Code {code}"),
                "temp_min": daily["temperature_2m_min"][i],
                "temp_max": daily["temperature_2m_max"][i],
                "rain_chance": daily["precipitation_probability_max"][i],
                "rain_mm": daily["precipitation_sum"][i],
                "business_impact": WEATHER_IMPACT.get(code, "Normal conditions")
            })

        return {
            "location": "Metro Manila",
            "current": {
                "temperature": current.get("temperature_2m"),
                "feels_like": current.get("apparent_temperature"),
                "humidity": current.get("relative_humidity_2m"),
                "wind_speed": current.get("wind_speed_10m"),
                "condition": WEATHER_DESCRIPTIONS.get(current_code, f"Code {current_code}"),
                "business_impact": WEATHER_IMPACT.get(current_code, "Normal conditions")
            },
            "forecast": forecast_days,
            "fetched_at": datetime.now().isoformat()
        }

    except httpx.HTTPError as e:
        logger.error(f"Weather API error: {e}")
        return {"error": "Could not fetch weather data", "details": str(e)}
    except Exception as e:
        logger.exception(f"Weather error: {e}")
        return {"error": "Weather service unavailable", "details": str(e)}
