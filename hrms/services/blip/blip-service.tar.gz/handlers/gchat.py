"""
Google Chat Webhook Handler

Handles incoming events from Google Chat and routes them
to the appropriate intent handler.
"""

import logging
from typing import Any

from config import settings

logger = logging.getLogger(__name__)


async def handle_gchat_event(
    event: dict,
    intent_parser: Any,
    frappe_client: Any
) -> dict:
    """
    Handle a Google Chat event.

    Args:
        event: The Google Chat event payload
        intent_parser: Claude AI intent parser instance
        frappe_client: Frappe API client instance

    Returns:
        Response dict with 'text' key for Google Chat
    """
    event_type = event.get("type", "")

    if event_type == "ADDED_TO_SPACE":
        return handle_added_to_space(event)

    elif event_type == "REMOVED_FROM_SPACE":
        return {"text": ""}  # No response needed

    elif event_type == "MESSAGE":
        return await handle_message(event, intent_parser, frappe_client)

    else:
        logger.warning(f"Unknown event type: {event_type}")
        return {"text": "I received an unknown event type."}


def handle_added_to_space(event: dict) -> dict:
    """Handle when Blip is added to a space or DM."""
    space_type = event.get("space", {}).get("type", "")
    user_name = event.get("user", {}).get("displayName", "there")

    if space_type == "DM":
        return {
            "text": (
                f"Hi {user_name}! I'm Blip, BEI's AI assistant.\n\n"
                "I can help you with:\n"
                "- Sales data (by store, area, or company-wide)\n"
                "- Food cost analysis\n"
                "- Commissary production\n"
                "- Inventory levels\n"
                "- HR info (leave, attendance)\n"
                "- Weather forecasts\n\n"
                "Just ask me anything! For example:\n"
                '- "What are sales at Market Market today?"\n'
                '- "Who is on leave tomorrow?"\n'
                '- "What is the weather forecast?"'
            )
        }
    else:
        return {
            "text": (
                "Hi everyone! I'm Blip, BEI's AI assistant. "
                "Mention me with your question and I'll help.\n\n"
                "Example: @Blip What are today's sales?"
            )
        }


async def handle_message(
    event: dict,
    intent_parser: Any,
    frappe_client: Any
) -> dict:
    """
    Handle an incoming message.

    1. Extract user info
    2. Parse intent with Claude AI
    3. Execute query against Frappe
    4. Format and return response
    """
    user = event.get("user", {})
    user_email = user.get("email", "")
    message = event.get("message", {})
    message_text = message.get("text", "").strip()

    # Remove @Blip mention if present
    message_text = message_text.replace("@Blip", "").strip()

    if not message_text:
        return {"text": "I didn't catch that. Could you please ask me a question?"}

    logger.info(f"Processing message from {user_email}: {message_text[:100]}...")

    try:
        # Build user context for permissions
        user_context = await get_user_context(user_email, frappe_client)

        # Parse intent using Claude AI
        parsed = await intent_parser.parse(
            message=message_text,
            user_context=user_context
        )

        logger.info(f"Parsed intent: {parsed.get('intent', 'unknown')}")

        # Execute the query based on intent
        result = await execute_intent(
            parsed=parsed,
            user_context=user_context,
            frappe_client=frappe_client
        )

        # Format the response
        response_text = await intent_parser.format_response(
            intent=parsed.get("intent"),
            data=result,
            user_context=user_context
        )

        return {"text": response_text}

    except Exception as e:
        logger.exception(f"Error processing message: {e}")
        return {
            "text": (
                "Sorry, I encountered an error processing your request. "
                "Please try again or rephrase your question."
            )
        }


async def get_user_context(user_email: str, frappe_client: Any) -> dict:
    """
    Get user context including permissions.

    Args:
        user_email: The user's email address
        frappe_client: Frappe API client

    Returns:
        User context dict with permissions
    """
    is_admin = user_email in settings.ADMIN_EMAILS

    context = {
        "email": user_email,
        "is_admin": is_admin,
        "roles": [],
        "employee": None,
        "store": None,
        "area": None
    }

    if is_admin:
        # Admin has full access
        context["roles"] = ["System Manager", "Administrator"]
        return context

    try:
        # Get user info from Frappe
        user_info = await frappe_client.get_user_context(user_email)
        context.update(user_info)
    except Exception as e:
        logger.warning(f"Could not get user context for {user_email}: {e}")

    return context


async def execute_intent(
    parsed: dict,
    user_context: dict,
    frappe_client: Any
) -> dict:
    """
    Execute the parsed intent against Frappe.

    Args:
        parsed: Parsed intent from Claude AI
        user_context: User permissions context
        frappe_client: Frappe API client

    Returns:
        Query result data
    """
    intent = parsed.get("intent", "unknown")
    entities = parsed.get("entities", {})

    # Route to appropriate handler based on intent
    if intent == "weather":
        from data.weather import get_weather_forecast
        return await get_weather_forecast(entities)

    elif intent == "leave_balance":
        return await frappe_client.get_leave_balance(
            employee=entities.get("employee") or user_context.get("employee"),
            user_context=user_context
        )

    elif intent == "leave_status":
        return await frappe_client.get_leave_applications(
            employee=entities.get("employee"),
            status=entities.get("status"),
            user_context=user_context
        )

    elif intent == "who_on_leave":
        return await frappe_client.get_employees_on_leave(
            date=entities.get("date"),
            store=entities.get("store"),
            user_context=user_context
        )

    elif intent == "attendance":
        return await frappe_client.get_attendance(
            employee=entities.get("employee"),
            date=entities.get("date"),
            user_context=user_context
        )

    elif intent == "team_attendance":
        return await frappe_client.get_team_attendance(
            date=entities.get("date"),
            store=entities.get("store"),
            user_context=user_context
        )

    elif intent == "sales":
        return await frappe_client.get_sales_data(
            store=entities.get("store"),
            area=entities.get("area"),
            period=entities.get("period"),
            user_context=user_context
        )

    elif intent == "food_cost":
        return await frappe_client.get_food_cost(
            store=entities.get("store"),
            period=entities.get("period"),
            user_context=user_context
        )

    elif intent == "inventory":
        return await frappe_client.get_inventory(
            store=entities.get("store"),
            item=entities.get("item"),
            user_context=user_context
        )

    elif intent == "commissary":
        return await frappe_client.get_commissary_production(
            product=entities.get("product"),
            date=entities.get("date"),
            user_context=user_context
        )

    elif intent == "help":
        return {"type": "help"}

    elif intent == "greeting":
        return {"type": "greeting", "user_name": user_context.get("employee_name", "")}

    else:
        return {"type": "unknown", "original_message": parsed.get("original_message", "")}
