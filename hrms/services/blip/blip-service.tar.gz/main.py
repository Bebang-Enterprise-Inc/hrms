"""
Blip: AI-Powered Company Assistant

Main FastAPI application that handles webhooks from Google Chat,
Telegram, and WhatsApp, and uses Claude AI to answer questions
about BEI's business.
"""

import logging
from contextlib import asynccontextmanager
from datetime import datetime

from fastapi import FastAPI, Request, HTTPException
from fastapi.responses import JSONResponse

from config import settings
from handlers.gchat import handle_gchat_event
from ai.intent_parser import IntentParser
from frappe_client import FrappeClient

# Configure logging
logging.basicConfig(
    level=getattr(logging, settings.LOG_LEVEL),
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)

# Global instances
intent_parser: IntentParser = None
frappe_client: FrappeClient = None


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Initialize and cleanup resources."""
    global intent_parser, frappe_client

    logger.info("Starting Blip AI Assistant...")

    # Initialize multi-model AI parser
    # Claude Haiku 4.5 for intent parsing, Gemini 3 Flash for formatting
    intent_parser = IntentParser(
        api_key=settings.ANTHROPIC_API_KEY,
        gemini_api_key=settings.GEMINI_API_KEY,
        model=settings.CLAUDE_MODEL,
        gemini_model=settings.GEMINI_MODEL
    )
    logger.info(f"Multi-model AI initialized: {settings.CLAUDE_MODEL} + {settings.GEMINI_MODEL}")

    # Initialize Frappe client
    frappe_client = FrappeClient()
    logger.info(f"Frappe client initialized: {settings.FRAPPE_URL}")

    yield

    logger.info("Shutting down Blip AI Assistant...")


app = FastAPI(
    title="Blip AI Assistant",
    description="AI-powered company assistant for BEI",
    version="1.0.0",
    lifespan=lifespan
)


@app.get("/health")
async def health_check():
    """Health check endpoint for monitoring."""
    return {
        "status": "healthy",
        "service": settings.SERVICE_NAME,
        "timestamp": datetime.utcnow().isoformat()
    }


@app.get("/api/status")
async def status():
    """Detailed status endpoint."""
    return {
        "status": "running",
        "service": settings.SERVICE_NAME,
        "version": "1.0.0",
        "frappe_url": settings.FRAPPE_URL,
        "claude_model": settings.CLAUDE_MODEL,
        "timestamp": datetime.utcnow().isoformat()
    }


@app.post("/webhook/gchat")
async def gchat_webhook(request: Request):
    """
    Google Chat webhook endpoint.

    Receives events when users message Blip in Google Chat.
    """
    try:
        event = await request.json()
        logger.info(f"Received Google Chat event: {event.get('type', 'unknown')}")

        response = await handle_gchat_event(
            event=event,
            intent_parser=intent_parser,
            frappe_client=frappe_client
        )

        return JSONResponse(content=response)

    except Exception as e:
        logger.exception(f"Error handling Google Chat event: {e}")
        return JSONResponse(
            content={"text": "Sorry, I encountered an error. Please try again."}
        )


@app.post("/webhook/telegram")
async def telegram_webhook(request: Request):
    """
    Telegram webhook endpoint.

    Receives updates when users message the Blip Telegram bot.
    """
    # TODO: Implement in Phase 5
    return {"status": "not_implemented"}


@app.post("/webhook/whatsapp")
async def whatsapp_webhook(request: Request):
    """
    WhatsApp webhook endpoint.

    Receives messages from WhatsApp Business API.
    """
    # TODO: Implement in Phase 5
    return {"status": "not_implemented"}


@app.post("/api/chat")
async def web_chat(request: Request):
    """
    Web chat API endpoint.

    For the chat widget in my.bebang.ph.
    """
    try:
        data = await request.json()
        user_email = data.get("user_email")
        message = data.get("message")

        if not user_email or not message:
            raise HTTPException(status_code=400, detail="user_email and message required")

        # Create a mock Google Chat event structure
        event = {
            "type": "MESSAGE",
            "user": {"email": user_email},
            "message": {"text": message},
            "space": {"type": "WEB"}
        }

        response = await handle_gchat_event(
            event=event,
            intent_parser=intent_parser,
            frappe_client=frappe_client
        )

        return response

    except HTTPException:
        raise
    except Exception as e:
        logger.exception(f"Error handling web chat: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=settings.SERVICE_PORT,
        reload=True
    )
